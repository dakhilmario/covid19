/* Source and licensing information for the line(s) below can be found at http://localhost/corona-website/covid19/core/misc/checkbox.js. */
(function(Drupal){Drupal.theme.checkbox=function(){return"<input type=\"checkbox\" class=\"form-checkbox\"/>"}})(Drupal)
/* Source and licensing information for the above line(s) can be found at http://localhost/corona-website/covid19/core/misc/checkbox.js. */